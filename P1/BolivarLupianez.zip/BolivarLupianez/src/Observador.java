/**
 *  @author Francisco Javier Bol�var Lupi��ez
 */

public interface Observador {
	public void manejarEvento();
}