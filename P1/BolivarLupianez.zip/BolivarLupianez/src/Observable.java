/**
 *  @author Francisco Javier Bol�var Lupi��ez
 */

public abstract class Observable {
	public abstract void notificar();
}
