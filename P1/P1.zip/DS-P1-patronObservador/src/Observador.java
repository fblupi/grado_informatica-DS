
public interface Observador {
	public void manejarEvento();
}