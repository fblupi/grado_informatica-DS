
public abstract class Observable {
	public abstract void notificar();
}
