package dinero;

public interface IDinero {
	public abstract IDinero add(IDinero d);
}
