public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Interprete interprete = new Interprete("Producto");
		System.out.println(interprete.printName());
		System.out.println(interprete.printFields());
		System.out.println(interprete.printMethods());
	}

}
